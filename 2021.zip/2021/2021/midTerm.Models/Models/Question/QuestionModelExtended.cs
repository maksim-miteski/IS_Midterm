﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace midTerm.Models.Models.Question
{
    public class QuestionModelExtended
    {
        public int Id { get; set; }
        [Required]
        [Validations.QuestionTextValidation]
        public string Text { get; set; }
        [Required(ErrorMessage = "Description field is required!"), StringLength(50)]
        public string Description { get; set; }

        public virtual ICollection<QuestionOptions> Options { get; set; }
    }
}
