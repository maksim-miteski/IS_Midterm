﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace midTerm.Models.Models.Question
{
    public class QuestionUpdateModel
    {
        [Required]
        public int Id { get; set; }
        [Required(ErrorMessage = "Text field is required!"), StringLength(50)]
        [Validations.QuestionTextValidation]
        public string Text { get; set; }
        [Required(ErrorMessage = "Description field is required!"), StringLength(50)]
        public string Description { get; set; }
    }
}
