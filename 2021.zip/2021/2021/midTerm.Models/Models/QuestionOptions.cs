﻿using System;
using System.Collections.Generic;
using System.Text;

namespace midTerm.Models.Models
{
    public class QuestionOptions
    {
        public int Id { get; set; }
        public string Text { get; set; }

        public Option.OptionModelBase Option { get; set; }
        public Question.QuestionModelBase Question { get; set; }
    }
}
