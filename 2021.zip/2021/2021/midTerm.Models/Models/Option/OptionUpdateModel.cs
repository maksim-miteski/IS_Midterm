﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace midTerm.Models.Models.Option
{
    public class OptionUpdateModel
    {
        public int Id { get; set; }
        [Required(ErrorMessage="Text field is required"),StringLength(50)]
        public string Text { get; set; }
        [Required(ErrorMessage = "Order field is required"), StringLength(50)]
        public int? Order { get; set; }

    }
}
