﻿using System;
using System.Collections.Generic;
using System.Text;

namespace midTerm.Models.Validations
{
    public class QuestionTextValidation
         : System.ComponentModel.DataAnnotations.ValidationAttribute
    {
        public override bool IsValid(object? value)
        {
            return (string)value == "Question";
        }

        public override string FormatErrorMessage(string name)
        {
            return $"{name} cannot be same as the description";
        }
    }
}
