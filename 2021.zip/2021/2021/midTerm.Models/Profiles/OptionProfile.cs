﻿using midTerm.Models.Models.Option;
using System;
using System.Collections.Generic;
using System.Text;
using AutoMapper;

    public class OptionProfile
        : Profile
    {
    public OptionProfile()
        {
        CreateMap<Option, OptionModelBase>().ReverseMap();
        CreateMap<Option, OptionModelExtended>();
        
        CreateMap<OptionCreateModel, Option>()
            .ForMember(dest => dest.Text, opt => opt.MapFrom(src => src.Text))
            .ForMember(dest => dest.Order, opt => opt.MapFrom(src => src.Order));

        CreateMap<OptionUpdateModel, Option>()
            .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.Id))
            .ForMember(dest => dest.Text, opt => opt.MapFrom(src => src.Text))
            .ForMember(dest => dest.Order, opt => opt.MapFrom(src => src.Order));
   
        }
    }

