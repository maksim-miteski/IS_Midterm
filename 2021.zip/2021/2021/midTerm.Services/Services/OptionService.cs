﻿
using midTerm.Models.Models.Option;
using midTerm.Services.Abstraction;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;

namespace midTerm.Services.Services
{
    public class OptionService
        : IOptionService
    {
        private readonly MidtermServicesDbContext _context;
        public OptionService(MidtermServicesDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task<bool> Delete(int id)
        {
            var entity = await _context.Options.FindAsync(id);
            _context.Options.Remove(entity);
            return await SaveAsync() > 0;
        }

        public Task<IEnumerable<OptionModelBase>> Get()
        {
            var options = await _context.Options.ToListAsync();
            return _mapper.Map<IEnumerable<OptionModelBase>>(options);
        }
           
            public async Task<OptionModelExtended> Get(int id)
        {
            var option = await _context.Options
               .Include(q => q.QuestionOptions)
               .ThenInclude(qo => qo.Question)
               .FirstOrDefaultAsync(q => q.Id == id);

            return _mapper.Map<OptionModelExtended>(option);
        }

        public async Task<OptionModelBase> Insert(OptionCreateModel model)
        {
            var entity = _mapper.Map<Option>(model);
            await _context.Options.AddAsync(entity);
            await SaveAsync();

            return _mapper.Map<OptionModelBase>(entity);
        }

        public async Task<OptionModelBase> Update(OptionUpdateModel model)
        {
            var entity = _mapper.Map<Option>(model);
            _context.Options.Attach(entity);
            _context.Entry(entity).State = EntityState.Modified;

            await SaveAsync();
            return _mapper.Map<OptionModelBase>(entity);
        }

        public async Task<int> SaveAsync()
        {
            return await _context.SaveChangesAsync();
        }
    }
}
