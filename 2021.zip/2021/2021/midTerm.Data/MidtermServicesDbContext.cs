﻿using Microsoft.EntityFrameworkCore;
using midTerm.Data.Entities;
using midTerm.Models.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace midTerm.Data
{
    class MidtermServicesDbContext 
        : DbContext
    {
        public MidtermServicesDbContext(DbContextOptions<MidtermServicesDbContext> options)
           : base(options)
        {
        }
        public DbSet<Question> Questions { get; set; }
        public DbSet<Option> Options { get; set; }



        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {


            modelBuilder.Entity<Question>(question =>
            {
                question.Property(q => q.Text).IsRequired();
                question.Property(q => q.Id).IsRequired();
                question.HasKey(q => q.Id);
                question.Property(q => q.Text).HasMaxLength(50).IsRequired();
                question.HasMany(q => q.Options);
            });

            modelBuilder.Entity<Option>(option =>
            {
                option.Property(o => o.Id).IsRequired();
                option.HasKey(o => o.Id);
                option.Property(o => o.Text).HasMaxLength(50).IsRequired();
                option.Property(o => o.Order).HasMaxLength(50).IsRequired();
                option.HasOne(o => o.Questions);
            });
        }
    }
}
